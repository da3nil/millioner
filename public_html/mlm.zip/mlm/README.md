# MLM-Website-Using-PHP-Binary-Plan-Version-1.0
This is the MLM Project created using PHP. This code is for the youtube channel    https://www.youtube.com/watch?v=0fBScrC0cKU&amp;list=PLnq9yHs8s_hm6LEwIJ4qlV53U6Fo--YZh
