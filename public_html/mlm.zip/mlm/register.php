<?php // include('server.php') ?>

<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
    
    <?php
    // мое решение
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
        //database
        $db_host = "localhost";
    	$db_user = "u549105306_lopat";
    	$db_pass = "Cjgy~s8Fp+BA+";
    	$db_name = "u549105306_mlm";
    	
    	$db =  mysqli_connect($db_host,$db_user,$db_pass,$db_name);
    	if(mysqli_connect_error()){
    		echo 'connect to database failed';
    	} else {
        	$email = $_POST["email"];
        	$password_one = $_POST["password_1"];
        	$password_two = $_POST["password_2"];
        	$username = $_POST["username"];
        // 	echo $email . ' | ' . $password_one . ' | ' . $username;
        // 	var_dump($email);
        	
        	if ($email == '') {
        	    echo "<script>alert('email error')</script>";
        	} else if ($password_one=='' or $password_two==''){
        	    echo "<script>alert('password error')</script>";
        	} else if ($password_one != $password_two){
        	    echo "<script>alert('password error')</script>";
        	} else if ($username == '') {
        	    echo "<script>alert('username error')</script>";
        	} else {
  
                $result_d = mysqli_query($db, "INSERT INTO users(email, password,name) VALUES ('$email','$password_one','$username')") or die (mysqli_error($db));
                echo "<script>alert('Успешно');</script>";
            }
    	}
    }   
?>	
  <form method="post" action="register.php">
  	<?php //include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" value="<?php // echo $username; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php // echo $email; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
</body>
</html>